create definer = jsj@`%` trigger DynamicMusic
    after insert
    on MEMBER
    for each row
BEGIN
INSERT INTO hjproject.DMUSIC(MEMBER_CODE, DM_SCORE, DM_COMBO) 
VALUES (NEW.MEMBER_CODE, '0', '0','0','0','0','0');
END;

