create definer = jsj@`%` trigger new_mailuser
    after insert
    on MEMBER
    for each row
begin
INSERT INTO mailbox.VIRTUAL_USERS
   (`domain_id`, `password` , `MWEBMAIL`, `MBOX`, `MEMBER_CODE`)
VALUES
   ('1', ENCRYPT(NEW.MPASSWD, CONCAT('$6$', SUBSTRING(SHA(RAND()), -16))), CONCAT(NEW.MID, '@mail.hjproject.kro.kr'), NEW.MID, NEW.MEMBER_CODE);
END;

